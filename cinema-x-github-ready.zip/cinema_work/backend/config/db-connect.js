// Lightweight local data connection used for the project demo.
// Replace this module with mongoose.connect(...) when MongoDB is added.
const fs = require('fs');
const path = require('path');
const usersPath = path.join(__dirname, '../data/users.json');
exports.readUsers = () => JSON.parse(fs.readFileSync(usersPath, 'utf8'));
exports.writeUsers = (users) => fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));
