const crypto = require('crypto');
exports.createUser = ({ name, email, password }) => ({ id: crypto.randomUUID(), name: name.trim(), email: email.trim().toLowerCase(), passwordHash: crypto.createHash('sha256').update(password).digest('hex'), createdAt: new Date().toISOString() });
exports.hashPassword = (password) => crypto.createHash('sha256').update(password).digest('hex');
exports.publicUser = ({ id, name, email, createdAt }) => ({ id, name, email, createdAt });
