const movies = require('../data/movies-data.json');
exports.trending = () => ({ results: movies });
exports.search = (query) => ({ results: movies.filter((movie) => movie.title.toLowerCase().includes((query || '').toLowerCase())) });
exports.details = (id) => movies.find((movie) => movie.id === Number(id));
