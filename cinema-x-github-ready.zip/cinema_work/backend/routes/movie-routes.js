const movieController = require('../controllers/movie-controllers');
exports.trending = () => movieController.trending();
exports.search = (query) => movieController.search(query);
exports.details = (id) => movieController.details(id);
