const authController = require('../controllers/auth-controllers');
exports.register = (body) => authController.register(body);
exports.login = (body) => authController.login(body);
