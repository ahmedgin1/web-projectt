const { readUsers } = require('../config/db-connect');
exports.currentUser = (authorization) => { try { const payload = JSON.parse(Buffer.from((authorization || '').replace('Bearer ', ''), 'base64url').toString()); return readUsers().find((user) => user.id === payload.id); } catch { return null; } };
