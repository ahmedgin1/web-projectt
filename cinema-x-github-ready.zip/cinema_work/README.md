# 🎬 Cinema X — Angular + Node.js

A university cinema web project built with **Angular** for the frontend and **Node.js** for the backend.

## Features

- Movie home page and movie details
- Movie search
- User registration and login
- Protected routes using an Angular Auth Guard
- User profile form
- Angular Signals
- Data binding and Angular control flow (`@if`, `@for`)
- Template-driven forms
- Reactive forms
- Angular `HttpClient`
- Authentication interceptor
- HTTP error interceptor
- Angular services
- Routing with `RouterLink` and Router navigation
- Node.js REST API
- JSON file storage for demo users

## Project structure

```text
cinema-x/
├── frontend/     # Angular application
├── backend/      # Node.js API
└── README.md
```

## Requirements

- Node.js 20+ recommended
- npm 10+

## 1. Run the backend

Open a terminal in the `backend` folder:

```bash
cd backend
npm install
npm start
```

The API runs on:

```text
http://localhost:4302
```

## 2. Run the frontend

Open a second terminal in the `frontend` folder:

```bash
cd frontend
npm install
npm start
```

Then open the local Angular URL shown by the terminal (normally `http://localhost:4200`).

## Important

Run the **backend first**, then the frontend. The frontend calls the API at:

```text
http://localhost:4302/api
```

## GitHub

`node_modules`, Angular build files, caches, `.env` files, and other generated files are excluded through `.gitignore`.

After cloning the repository, install dependencies separately inside `frontend` and `backend` using `npm install`.

## Academic requirements covered

| Requirement | Implementation |
|---|---|
| Components | Navbar, Home, Login, Search, Movie Details, Profile |
| Data Binding | Angular template bindings across pages |
| Control Flow | `@if` and `@for` |
| Signals | Auth state signals |
| Template-driven Forms | Login/Search forms |
| Reactive Forms | Profile form |
| Connect Frontend with Backend | Angular `HttpClient` → Node API |
| HttpClient | Auth and Movie services |
| Interceptors | Auth + HTTP error interceptor |
| Services | `AuthService`, `MovieService` |
| Routing | Route definitions, `RouterLink`, Router navigation |
| Route protection | `authGuard` |
