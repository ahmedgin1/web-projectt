import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';

export const authGuard: CanActivateFn = (route, state) => {
  return localStorage.getItem('cinema_token') ? true : inject(Router).createUrlTree(['/login']);
};
