import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MovieService {
  private http = inject(HttpClient);
  private api = 'http://localhost:4302/api/movies';

  getTrendingMovies(): Observable<any> {
    return this.http.get<any>(`${this.api}/trending`);
  }

  getMovieDetails(id: string): Observable<any> {
    return this.http.get<any>(`${this.api}/${id}`);
  }

  searchMovies(query: string): Observable<any> {
    return this.http.get<any>(`${this.api}/search?q=${encodeURIComponent(query)}`);
  }
}
