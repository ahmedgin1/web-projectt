import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MovieService } from '../../services/movie';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './home.html',
  styleUrl: './home.scss'
})
export class HomeComponent implements OnInit {
  private movieService = inject(MovieService);
  movies = signal<any[]>([]);

  ngOnInit(): void {
    this.movieService.getTrendingMovies().subscribe({
      next: (res: any) => {
        console.log('Movies fetched:', res); // عشان تشوف الداتا في الـ Console لو حابب
        // نتأكد إننا بنخزن المصفوفة سواء كانت في res.results أو res مباشرة
        if (res && res.results) {
          this.movies.set(res.results);
        } else if (Array.isArray(res)) {
          this.movies.set(res);
        }
      },
      error: (err) => {
        console.error('Error fetching movies:', err);
      }
    });
  }
}
