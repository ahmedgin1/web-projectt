import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { MovieService } from '../../services/movie';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './search.html'
})
export class SearchComponent {
  private movieService = inject(MovieService);
  searchQuery = signal<string>('');
  searchResults = signal<any[]>([]);
  isLoading = signal<boolean>(false);

  // دالة البحث الأساسية اللي بتشتغل لما تدوس زرار أو تضغط Enter
  onSearch() {
    const query = this.searchQuery().trim();
    if (!query) {
      this.searchResults.set([]);
      return;
    }

    this.isLoading.set(true);
    this.movieService.searchMovies(query).subscribe({
      next: (res) => {
        this.searchResults.set(res.results || []);
        this.isLoading.set(false);
      },
      error: (err) => {
        console.error('Error searching movies:', err);
        this.isLoading.set(false);
      }
    });
  }
}
