import { Component, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth';
@Component({standalone:true,imports:[ReactiveFormsModule],templateUrl:'./profile.html'})
export class ProfileComponent { private fb=inject(FormBuilder); private router=inject(Router); auth=inject(AuthService); saved=signal(false); form=this.fb.nonNullable.group({displayName:[this.auth.user()?.name||'', [Validators.required,Validators.minLength(2)]], favouriteGenre:['Science Fiction',Validators.required]}); save(){if(this.form.invalid)return;this.saved.set(true);setTimeout(()=>this.router.navigateByUrl('/'),900);} }
