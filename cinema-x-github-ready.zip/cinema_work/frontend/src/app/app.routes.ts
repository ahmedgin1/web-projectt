import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home';
import { MovieDetailsComponent } from './pages/movie-details/movie-details';
import { SearchComponent } from './pages/search/search';
import { LoginComponent } from './pages/login/login';
import { authGuard } from './guards/auth-guard';
import { ProfileComponent } from './pages/profile/profile';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'movie/:id', component: MovieDetailsComponent },
  { path: 'search', component: SearchComponent, canActivate: [authGuard] },
  { path: 'profile', component: ProfileComponent, canActivate: [authGuard] },
  { path: 'login', component: LoginComponent },
  { path: '**', redirectTo: '' },
];
